# Minimum-Enclosing-Circle
The program draws the smallest circle enclosing the given points with OpenGL in c.
